package atvd2.view;

import atvd2.controller.encadDuplaController;

public class view {

	public static void main(String[] args) {
		encadDuplaController encad = new encadDuplaController();
		
		encad.inserirInicio(2);
		encad.inserirInicio(1);
		
		encad.exibir();
		
		encad.inserirInicio(0);
		System.out.println(" ");
		encad.exibir();
		
		System.out.println(" ");
		
		encad.inserirFinal(3);
		encad.exibir();
		

	}

}
