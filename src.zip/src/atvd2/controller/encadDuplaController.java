package atvd2.controller;

import atvd2.model.No;
public class encadDuplaController {
	private No inicio = null;
	private No fim = null;
	
	
	
	public void inserirInicio(int valor) {
		No novoNo = new No(valor);
		
		if(inicio == null) {
			inicio = fim = novoNo;
		}else {
			novoNo.setProximo(inicio);
			novoNo.setAnterior(null);
			inicio = novoNo;
		}
		
		
	}
	
	public void inserirFinal(int valor) {
		No novoNo = new No(valor);
		if(inicio == null) {
			inicio = fim = novoNo;
		}else {
			fim.setProximo(novoNo);
			novoNo.setAnterior(fim);
			fim = novoNo;
		}
		
		
	}
	
	public void exibir() {
		No atual = inicio;
		
		while(atual != null) {
			System.out.print(atual.getValor() + " -> ");
			atual = atual.getProximo();
		}
		
		System.out.print("null");
	}
	
}
